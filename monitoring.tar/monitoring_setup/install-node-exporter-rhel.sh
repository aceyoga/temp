#!/bin/bash

# Define Node Exporter version
NODE_EXPORTER_VERSION="1.3.1"

# Update and install required packages
sudo yum update -y
sudo yum install -y policycoreutils-python-utils nano

# Open ports
# Open port 9090 for Prometheus
sudo firewall-cmd --zone=trusted --add-port=9090/tcp --permanent
sudo semanage port -a -t http_port_t -p tcp 9090

# Open port 9091 for Pushgateway
sudo firewall-cmd --zone=trusted --add-port=9091/tcp --permanent
sudo semanage port -a -t http_port_t -p tcp 9091

# Open port 9100 for Node Exporter
sudo firewall-cmd --zone=trusted --add-port=9100/tcp --permanent
sudo semanage port -a -t http_port_t -p tcp 9100

# Reload the firewall to apply changes
sudo firewall-cmd --reload

# Download and extract Node Exporter
echo "Downloading and extracting Node Exporter v$NODE_EXPORTER_VERSION..."
curl -sL https://github.com/prometheus/node_exporter/releases/download/v${NODE_EXPORTER_VERSION}/node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz | sudo tar xvz -C /opt

echo "Copying Node Exporter systemd service file..."
sudo cp "monitoring/node_exporter.service" /etc/systemd/system/node_exporter.service

# Reload systemd to recognize the new service
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable and start the Node Exporter service
echo "Enabling and starting Node Exporter service..."
sudo systemctl enable --now node_exporter

echo "Node Exporter installation and setup complete."