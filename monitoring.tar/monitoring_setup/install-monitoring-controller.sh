#!/bin/bash

# Run install-node-exporter.sh first before running this script
sudo bash install-node-exporter.sh

# Define versions
GRAFANA_VERSION="8.5.4"
PROMETHEUS_VERSION="2.36.0"

# Install Grafana
echo "Downloading and installing Grafana v$GRAFANA_VERSION..."
wget -q https://dl.grafana.com/oss/release/grafana_${GRAFANA_VERSION}_amd64.deb -P /opt
sudo apt-get update
sudo apt-get install -y adduser libfontconfig1
sudo dpkg -i /opt/grafana_${GRAFANA_VERSION}_amd64.deb

# Ensure Grafana directories exist
echo "Ensuring Grafana directories exist..."
sudo mkdir -p /etc/grafana/provisioning/dashboards
sudo mkdir -p /etc/grafana/provisioning/datasources
sudo mkdir -p /var/lib/grafana/dashboards

# Install Prometheus
echo "Downloading and installing Prometheus v$PROMETHEUS_VERSION..."
wget -qO- https://github.com/prometheus/prometheus/releases/download/v${PROMETHEUS_VERSION}/prometheus-${PROMETHEUS_VERSION}.linux-amd64.tar.gz | sudo tar xvz -C /opt

# Copy Grafana configurations
echo "Configuring Grafana..."
sudo cp monitoring/grafana_dashboard.yaml /etc/grafana/provisioning/dashboards/grafana_dashboard.yaml
sudo cp monitoring/grafana_datasource.yaml /etc/grafana/provisioning/datasources/grafana_datasource.yaml
sudo cp monitoring/node-exporter-full_rev27.json /var/lib/grafana/dashboards/node-exporter-full_rev27.json

# Copy Prometheus configurations
echo "Configuring Prometheus..."
sudo cp monitoring/prometheus.yml /opt/prometheus-${PROMETHEUS_VERSION}.linux-amd64/prometheus.yml
sudo cp monitoring/prometheus.service /lib/systemd/system/prometheus.service

# Reload systemd to recognize new services
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable and start Grafana and Prometheus services
echo "Enabling and starting Grafana and Prometheus services..."
sudo systemctl enable --now grafana-server
sudo systemctl restart grafana-server
sudo systemctl enable --now prometheus
sudo systemctl restart prometheus

echo "Grafana and Prometheus installation and setup complete."