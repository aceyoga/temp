#!/bin/bash

# Define Node Exporter version
NODE_EXPORTER_VERSION="1.3.1"

# Download and extract Node Exporter
echo "Downloading and extracting Node Exporter v$NODE_EXPORTER_VERSION..."
wget -qO- https://github.com/prometheus/node_exporter/releases/download/v${NODE_EXPORTER_VERSION}/node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz | sudo tar xvz -C /opt

echo "Copying Node Exporter systemd service file..."
sudo cp "monitoring/node_exporter.service" /etc/systemd/system/node_exporter.service

# Reload systemd to recognize the new service
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable and start the Node Exporter service
echo "Enabling and starting Node Exporter service..."
sudo systemctl enable --now node_exporter

echo "Node Exporter installation and setup complete."